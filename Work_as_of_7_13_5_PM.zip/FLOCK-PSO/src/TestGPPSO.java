
public class TestGPPSO {

	public static void main(String[] args) {
		int numTrees = 12;
		Population pop = new Population(numTrees);
		
	}

}
